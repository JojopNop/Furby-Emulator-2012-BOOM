const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT  = path.join(ROOT, 'manifest.json');

const AUDIO_DIR  = 'English 2012 - Audio';
const IMAGES_DIR = 'English 2012 - Images';

// ... остальное ровно как в 2012, но model: 'Boom'
function numericIndex(filename) {
    const m = filename.match(/(\d+)/);
    return m ? parseInt(m[1], 10) : -1;
}

function scan(folder, exts) {
    const dir = path.join(ROOT, folder);
    const results = [];
    if (!fs.existsSync(dir)) return results;
    (function walk(current) {
        for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
            const full = path.join(current, entry.name);
            if (entry.isDirectory()) { walk(full); continue; }
            if (!exts.includes(path.extname(entry.name).toLowerCase())) continue;
            const rel = path.relative(ROOT, full).split(path.sep).join('/');
            results.push({ name: entry.name, path: rel, size: fs.statSync(full).size, idx: numericIndex(entry.name) });
        }
    })(dir);
    return results.sort((a, b) => a.idx - b.idx);
}

const manifest = {
    model: 'Boom',
    audio:  scan(AUDIO_DIR,  ['.wav', '.mp3', '.ogg', '.m4a']),
    images: scan(IMAGES_DIR, ['.bmp', '.png', '.jpg', '.jpeg', '.gif']),
    generatedAt: new Date().toISOString()
};
fs.writeFileSync(OUT, JSON.stringify(manifest, null, 2));

const check = (list, label) => {
    let gaps = 0, dups = 0;
    for (let i = 1; i < list.length; i++) {
        if (list[i].idx === list[i-1].idx) dups++;
        else if (list[i].idx - list[i-1].idx > 1) gaps++;
    }
    console.log(`${label}: ${list.length} files, gaps: ${gaps}, dups: ${dups}`);
    if (list.length) console.log(`  range: ${list[0].idx} … ${list[list.length-1].idx}`);
};
check(manifest.audio,  'Audio');
check(manifest.images, 'Images');